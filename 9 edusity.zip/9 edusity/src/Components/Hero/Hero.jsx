import React from 'react'
import './Hero.css'
import dark_arrow from '../../assets/dark-arrow.png'

const Hero = () => {
  return (
    <div className='hero'>
        <div className="hero-text">
            <h1> We believe students  should grow in knowledge thrived environment</h1>
            <p> Thriving in a supportive campus community, our university nurtures students to excel academically and socially.
                 With robust resources and inclusive initiatives, we empower future leaders to innovate and contribute globally, 
                 shaping a brighter tomorrow</p>
            <button className='btn'> Explore more <img src={dark_arrow} alt="" /> </button>
        </div>
      
    </div>
  )
}

export default Hero
