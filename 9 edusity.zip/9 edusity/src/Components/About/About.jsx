import React from 'react'
import './About.css'
import about_img from '../../assets/about.avif'
import play_icon from '../../assets/play-icon.png'

const About = () => {
  return (
    <div className='about'>
        <div className="about-left">
            <img src={about_img} alt="" className='about-img' />
            <img src={play_icon} alt="" className='play-icon'/>

        </div>
        <div className="about-right">
            <h3>ABOUT UNIVERSITY</h3>
            <h2> Nurturing Tommorow's Leaders Today </h2>
            <p> Our University offers a dynamic and innovative education with a focus on technology and creativity. 
                Our cutting-edge programs include state-of-the-art gaming and esports facilities, allowing students to
                 immerse themselves in both academic excellence and the world of gaming. Join us to elevate your 
                 learning and gaming experience to new heights!  </p>
            <p>At Our University, we are committed to providing a holistic education that blends rigorous academics with 
                experiential learning. Our diverse range of programs is designed to equip students with the skills and 
                knowledge needed for the future. With a strong emphasis on innovation and technology, our campus features
                 advanced labs, collaborative spaces, and a thriving community. Whether your passion lies in science, arts, 
                 or gaming, XYZ University is dedicated to nurturing your potential and preparing you for success.</p>

        </div>
      
    </div>
  )
}

export default About
