import React, { useRef } from 'react'
import './Testimonials.css'
import next_icon from '../../assets/next-icon.png'
import back_icon from '../../assets/back-icon.png'
import user_1 from '../../assets/user-1.jpg'
import user_2 from '../../assets/user-2.avif'
import user_3 from '../../assets/user-3.jpg'
import user_4 from '../../assets/user-4.jpg'

const Testimonials = () => {

    const slider = useRef();
    let tx = 0;

    const slideForward = () => {
        if(tx > -50){
            tx -= 25;
        }
        slider.current.style.tranform = `translateX(${tx}%)`;

    }

    const SlideBackward = () => {
        if(tx < 0){
            tx += 25;
        }
        slider.current.style.tranform = `translateX(${tx}%)`;
     
    }

  return (
    <div className='testimonials'>
        <img src={next_icon} alt="" className='next-btn' onClick={slideForward}/>
        <img src={back_icon} alt="" className='back-btn' onClick={SlideBackward}/>
        <div className="slider">
            <ul>
                <li>
                    <div className="slide">
                        <div className="user-info">
                            <img src={user_1} alt="" />
                            <div>
                                <h3>Alya Abranchi</h3>
                                <span>Branklin, Germany</span>
                            </div>
                        </div>
                        <p>Completing my degree at the university was a transformative experience. The diverse curriculum,
                             supportive faculty, and hands-on projects prepared me well for my career. I gained not only 
                             academic knowledge but also valuable skills in teamwork and problem-solving. I'm grateful for 
                             the opportunities and connections I made, and I feel confident moving forward into the professional world.</p>
                    </div>
                </li>
                <li>
                    <div className="slide">
                        <div className="user-info">
                            <img src={user_2} alt="" />
                            <div>
                                <h3>Alex Ranejaa</h3>
                                <span>Brampton, Canada</span>
                            </div>
                        </div>
                        <p>Completing my degree at the university was a transformative experience. The diverse curriculum,
                             supportive faculty, and hands-on projects prepared me well for my career. I gained not only 
                             academic knowledge but also valuable skills in teamwork and problem-solving. I'm grateful for 
                             the opportunities and connections I made, and I feel confident moving forward into the professional world.</p>
                    </div>
                </li>
                <li>
                    <div className="slide">
                        <div className="user-info">
                            <img src={user_3} alt="" />
                            <div>
                                <h3>Anastasiya gandiors</h3>
                                <span>Riga, Latvia</span>
                            </div>
                        </div>
                        <p>Completing my degree at the university was a transformative experience. The diverse curriculum,
                             supportive faculty, and hands-on projects prepared me well for my career. I gained not only 
                             academic knowledge but also valuable skills in teamwork and problem-solving. I'm grateful for 
                             the opportunities and connections I made, and I feel confident moving forward into the professional world.</p>
                    </div>
                </li>
                <li>
                    <div className="slide">
                        <div className="user-info">
                            <img src={user_4} alt="" />
                            <div>
                                <h3>David balochia</h3>
                                <span>Argentina, South America</span>
                            </div>
                        </div>
                        <p>Completing my degree at the university was a transformative experience. The diverse curriculum,
                             supportive faculty, and hands-on projects prepared me well for my career. I gained not only 
                             academic knowledge but also valuable skills in teamwork and problem-solving. I'm grateful for 
                             the opportunities and connections I made, and I feel confident moving forward into the professional world.</p>
                    </div>
                </li>
            </ul>
        </div>

      
    </div>
  )
}


export default Testimonials